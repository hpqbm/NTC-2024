import json
import boto3
import re
from botocore.config import Config
import ast


botoconfig = Config(read_timeout=1000)

my_config = Config(
    region_name = 'us-east-1',
    signature_version = 'v4',
    retries = {
        'max_attempts': 3,
        'mode': 'standard'
    }
)

bedrock_rt = boto3.client("bedrock-runtime", config = my_config)

def create_claude_body(
    messages = [{"role": "user", "content": "Hello!"}],
    system = "You are an expert in answering questions on Science, English and Mother Tomngue",
    token_count=150,
    temp=0, 
    topP=1,
    topK=250, 
    stop_sequence=["Human"]):

    """
    Simple function for creating a body for Anthropic Claude models for the Messages API.
    https://docs.anthropic.com/claude/reference/messages_post
    """
    body = {
        "messages": messages,
        "max_tokens": token_count,
        "system":system,
        "temperature": temp,
        "anthropic_version":"",
        "top_k": topK,
        "top_p": topP,
        "stop_sequences": stop_sequence
    }

    return body
    
def get_claude_response(messages="", 
                        system = "",
                        token_count=10000, 
                        temp=0,
                        topP=1, 
                        topK=250, 
                        stop_sequence=["\n\n"], 
                        model_id = "anthropic.claude-3-haiku-20240307-v1:0"):
    """
    Simple function for calling Claude via boto3 and the invoke_model API. 
    """
    body = create_claude_body(messages=messages, 
                              system=system,
                              token_count=token_count, 
                              temp=temp,
                              topP=topP, 
                              topK=topK, 
                              stop_sequence=stop_sequence)
    response = bedrock_rt.invoke_model(modelId=model_id, body=json.dumps(body))
    response = json.loads(response['body'].read().decode('utf-8'))

    return response


def gen_prompt(level, chapter):

    prompt = f'''
    You are an examination creator bot with expertise in coming up with intelligent questions and model answers based 
    on the chapter provided. The chapter can be on topics of Science, English and Chinese. 
    
    The questions can be in`MCQ` format which refers to questions where multiple choice of answers are given to choose from with 
    only one right answer, whereas `Open-ended` questions are questions that require answers that need to be explained with reasonings.
    
    Only generate questions in {level} format.
    
    First generate at least 10 questions. 
    Then for every question generated, please provide a model answer also.
    
    Encapsulate the questions in the tag <question></question> and the corresponding answers in
    the tag <answer></answer>.
    
    Please separate the question-answer pairs in the following format:
    
    <pair>
    <question></question>
    <answer></answer>
    </pair>
    
    Make sure the questions and answers are in the same language as the chapter.
    
    Lets get started. Please come up with questions and model answers based on the following chapter.
    
    {chapter}
    
    '''

    return prompt


def getmultitagtext(Inp_STR, tag="Question"):

    #tag = "Question"

    matches = re.findall(r"<"+tag+">(.*?)</"+tag+">", Inp_STR, flags=re.DOTALL)
    return matches


def call_bedrock(msg):
    
    # Create a Bedrock Runtime client in the AWS Region of your choice.
    client = boto3.client("bedrock-runtime", region_name="us-east-1", config=botoconfig)
    
    # Set the model ID, e.g., Claude 3 Haiku.
    model_id = "anthropic.claude-3-haiku-20240307-v1:0"
    
    # Format the request payload using the model's native structure.
    native_request = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 100000,
        "temperature": 0.5,
        "messages": msg,
    }
    
    # Convert the native request to JSON.
    request = json.dumps(native_request)
    
    try:
        # Invoke the model with the request.
        response = client.invoke_model(modelId=model_id, body=request)
    
    except (ClientError, Exception) as e:
        print(f"ERROR: Can't invoke '{model_id}'. Reason: {e}")
        exit(1)

    # Decode the response body.
    model_response = json.loads(response["body"].read())
    
    # Extract and print the response text.
    response_text = model_response["content"][0]["text"]
    print(response_text)
    
    return response_text



def lambda_handler(event, context):
    # TODO implement
    
    #print("event", event)
    
    #chapter = ast.literal_eval(event['body'])
    #chapter = event['body']
    print("event: ",event)

    messages = ast.literal_eval(event['body'])[0] #[event['body']]
    diff_level = messages["level"]
    chapter = messages["content"]
    prompt = gen_prompt(diff_level, chapter)
    
    msg = [{"role":"user", "content":prompt}]
    
    #modelID = "anthropic.claude-v2:1"
    #modelID = "anthropic.claude-v2"
    #modelID = "anthropic.claude-3-haiku-20240307-v1:0"
    '''
    try:
        text_resp = get_claude_response(
            messages=msg,
            token_count=10000,
            temp=0,
            topP=1,
            topK=0,
            stop_sequence=["Human: "],
            model_id=modelID
        )
    except:
        print("Something with the response from Claude....")
    '''

    print('msg: ', msg)
    print("Calling Bedrock....")
    response = call_bedrock(msg)
        
    #print("text_resp: ",text_resp)

    #lang = getmultitagtext(text_resp['content'][0]['text'], "lang")
    #subject = getmultitagtext(text_resp['content'][0]['text'], "subject")
    #answer = getmultitagtext(text_resp['content'][0]['text'], "answer")
    answer = getmultitagtext(response, "pair")
    print(answer)
    
    #result = {"lang": lang, "subject": subject, "answer": answer}
    result = {"lang": "", "subject": "", "answer": answer}
    
    return {
        'statusCode': 200,
        'body': json.dumps(result)
    }

