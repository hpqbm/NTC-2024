
# Initialise libraries›
import json
import boto3
import re
from botocore.config import Config
from botocore.exceptions import ClientError
import ast


my_config = Config(
    region_name = 'us-east-1',
    signature_version = 'v4',
    retries = {
        'max_attempts': 3,
        'mode': 'standard'
    }
)

bedrock_rt = boto3.client("bedrock-runtime", config = my_config)

def create_claude_body(
    messages = [{"role": "user", "content": "Hello!"}],
    system = "You are an expert in answering questions on Science, English and Mother Tongue",
    token_count=150,
    temp=0, 
    topP=1,
    topK=250, 
    stop_sequence=["Human"]):

    """
    Simple function for creating a body for Anthropic Claude models for the Messages API.
    https://docs.anthropic.com/claude/reference/messages_post
    """
    body = {
        "messages": messages,
        "max_tokens": token_count,
        "system":system,
        "temperature": temp,
        "anthropic_version":"",
        "top_k": topK,
        "top_p": topP,
        "stop_sequences": stop_sequence
    }

    return body
    
def get_claude_response(messages="", 
                        system = "",
                        token_count=10000, 
                        temp=0,
                        topP=1, 
                        topK=250, 
                        stop_sequence=["\n\n"], 
                        model_id = "anthropic.claude-3-haiku-20240307-v1:0"):
    """
    Simple function for calling Claude via boto3 and the invoke_model API. 
    """
    body = create_claude_body(messages=messages, 
                              system=system,
                              token_count=token_count, 
                              temp=temp,
                              topP=topP, 
                              topK=topK, 
                              stop_sequence=stop_sequence)
    response = bedrock_rt.invoke_model(modelId=model_id, body=json.dumps(body))
    response = json.loads(response['body'].read().decode('utf-8'))

    return response


def gen_prompt(question, qcontext):

    prompt = f'''
    You are a primarily english speaking bot with expertise in answering questions of primary school students. 
    For every question asked, put the answer within the following tags <answer> and </answer>. 
    
    If the question is a greetings or a compliment please respond back appropriately with politeness.
    
    If you do not know the answer to a question say - 'Sorry!! I am do not know how to answer that question. I am still learning.'
    
    Make sure your answer is primarily in English but if the question is in some other language, answer the question in that 
    language. But after answering the question revert back to English. \n\n
    '''
    if len(qcontext) > 0:
        prompt += f'''
        Given the context of the conversation,
        
        {qcontext}
        
        '''
    
    prompt += f'''
        answer the question from the user:
        
        {question}
    
        '''

    return prompt


def getmultitagtext(Inp_STR, tag="Question"):

    #tag = "Question"

    matches = re.findall(r"<"+tag+">(.*?)</"+tag+">", Inp_STR, flags=re.DOTALL)
    return matches
    
def call_bedrock(msg):
    
    # Create a Bedrock Runtime client in the AWS Region of your choice.
    client = boto3.client("bedrock-runtime", region_name="us-east-1")
    
    # Set the model ID, e.g., Claude 3 Haiku.
    model_id = "anthropic.claude-3-haiku-20240307-v1:0"
    
    # Format the request payload using the model's native structure.
    native_request = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 512,
        "temperature": 0.5,
        "messages": msg,
    }
    
    # Convert the native request to JSON.
    request = json.dumps(native_request)
    
    try:
        # Invoke the model with the request.
        response = client.invoke_model(modelId=model_id, body=request)
    
    except (ClientError, Exception) as e:
        print(f"ERROR: Can't invoke '{model_id}'. Reason: {e}")
        exit(1)

    # Decode the response body.
    model_response = json.loads(response["body"].read())
    
    # Extract and print the response text.
    response_text = model_response["content"][0]["text"]
    print(response_text)
    
    return response_text


def lambda_handler(event, context):
    # TODO implement
    
    print("event", event)
    #print("context", context)
    
    #return {
    #    'statusCode': 200,
    #    'body': json.dumps(event)
    #}
    
    #print("Elements in event: ", event['body'])
    #print("Elements in context: ", context)
    
    messages = [event['body']] #ast.literal_eval(event['body'])
    #print(f"messages: {type(messages)}: ", messages)
    question = messages[-1]["content"]
    print("question: ",question)
    
    qcontext = ""
    if len(messages) > 1:
        for ele in messages[-3:-1]:
            #print("ele :", ele)
            role = ele["role"]
            content = ele["content"]
            temp = f"\n {{ \n'role': '{role}', \n'content': '{content}''\n}}\n"
            #print("temp --> ",temp)
            qcontext += temp
            #print("qcontext --> ",qcontext)
        #qcontext = event['body'][-3:-1]
    
    #print("query context: ",qcontext)
    
    prompt = gen_prompt(question, qcontext)
    #print("prompt: ",prompt)
    
    msg = [{"role":"user", "content":prompt}]
    
    #modelID = "anthropic.claude-v2:1"
    #modelID = "anthropic.claude-v2"
    #modelID = "anthropic.claude-3-haiku-20240307-v1:0"
    
    '''
    try:
        text_resp = get_claude_response(
            messages=msg,
            token_count=10000,
            temp=0,
            topP=1,
            topK=0,
            stop_sequence=["Human: "],
            model_id=modelID
        )
    except:
        print("Something with the response from Claude....")
        
    print("text_resp: ",text_resp)
    '''
    print('msg: ', msg)
    response = call_bedrock(msg)

    #lang = getmultitagtext(text_resp['content'][0]['text'], "lang")
    #subject = getmultitagtext(text_resp['content'][0]['text'], "subject")
    answer = getmultitagtext(response, "answer")
    
    #result = {"lang": lang, "subject": subject, "answer": answer}
    result = {"lang": "", "subject": "", "answer": answer}
    
    return {
        'statusCode': 200,
        'body': json.dumps(result)
    }

